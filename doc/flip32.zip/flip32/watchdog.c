/*
 * gestorThreads.c
 *
 *  Created on: 01/10/2010
 *      Author: joaquin
 */
#include "ch.h"
#include "hal.h"
#include "chprintf.h"
#include "watchdog.h"

extern BaseSequentialStream *tty1;

static THD_WORKING_AREA(waThreadReavivaWatchDog, 128);
static THD_FUNCTION(ThreadReavivaWatchDog, arg) {
	(void)arg;
	chRegSetThreadName("aliveWD");
    while (TRUE)
    {
		/* Reload IWDG counter */
        wdg_lld_reset(&WDGD1);
		//IWDG->KR = ((uint16_t)0xAAAA);
		osalThreadSleepMilliseconds(100);
    }
    return;
}

//
//void arrancaWatchDog(void)
//{
//    /* IWDG timeout equal to 280 ms (the timeout may varies due to LSI frequency
//       dispersion) */
//	/* Arranca reloj LSI */
//	RCC->CSR = 1;
//	while ((RCC->CSR&2)!=2) chThdSleepMilliseconds(10);
//    IWDG->KR = IWDG_WriteAccess_Enable;     /* Enable write access to IWDG_PR and IWDG_RLR registers */
//    IWDG->PR = IWDG_Prescaler_256;     /* IWDG counter clock: 40KHz(LSI) / 128 = 40/128 KHz */
//    IWDG->RLR = 0x100;     /* Set counter reload value to 0x100<>0,8s 0xFFF => <>13s */
//    IWDG->KR = IWDG_WriteAccess_Disable;
//    IWDG->KR = ((uint16_t)0xAAAA);     /* Reload IWDG counter */
//    IWDG->KR = ((uint16_t)0xCCCC);     /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
//    chThdCreateStatic(waThreadReavivaWatchDog, sizeof(waThreadReavivaWatchDog), NORMALPRIO, ThreadReavivaWatchDog, NULL);
//    chprintf(tty1, "Watchdog started\r\n");
//	osalThreadSleepMilliseconds(100);
//}

/* IWDG timeout equal to 280 ms (the timeout may varies due to LSI frequency dispersion) */
static WDGConfig wdgConfig = {
  STM32_IWDG_PR_256,  /* IWDG counter clock: 40KHz(LSI) / 128 = 40/128 KHz */
  0x100               /* Set counter reload value to 0x100<>0,8s 0xFFF => <>13s */
};

void arrancaWatchDog(void)
{

  wdgStart(&WDGD1, &wdgConfig);
  chThdCreateStatic(waThreadReavivaWatchDog, sizeof(waThreadReavivaWatchDog), NORMALPRIO, ThreadReavivaWatchDog, NULL);
  chprintf(tty1, "Watchdog started\r\n");
  osalThreadSleepMilliseconds(100);
}

