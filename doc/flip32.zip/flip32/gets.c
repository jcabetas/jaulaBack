/*
 * gets.c
 *
 *  Created on: 26/03/2013
 *      Author: joaquin
 */

#include "ch.h"
#include "hal.h"

#include "tty.h"
#include "string.h"
#include "chprintf.h"

extern BaseSequentialStream *tty1;

uint8_t chgetch(void)
{
	uint8_t carReceived;
	carReceived = sdGet(&SD1);
	return carReceived;
}

uint8_t *chgets(void)
{
    static uint8_t buffer[50];
    uint8_t ch,ch1,ch2;
    int pos=0;
    while (pos<49)
      {
      ch = chgetch();
      if (ch=='\n' || ch=='\r')
         {
         chprintf(tty1,"%c",ch);
         break;
         }
      if (ch==8 && pos>0)
         {
    	  chprintf(tty1,"%c",ch);
         pos--;
         continue;
         }
      if (ch>=0x20)
         {
    	  chprintf(tty1,"%c",ch);
         buffer[pos++] = ch;
         continue;
         }
      if (ch==0x1b) // escape
         {
         ch1 = chgetch();
         if (ch1 != 0x5b) continue; // no es codigo de direccion
         ch2 = chgetch();
         if (ch2 ==0x44 && pos>0)
            {
        	 chprintf(tty1,"%c",8);
            pos--; //flecha izquierda
            }
         continue;
         }
      }
    buffer[pos]=0;
    return buffer;
}


/**
  * @brief  Convert a string to an integer
  * @param  inputstr: The string to be converted
  * @param  intnum: The intger value
  * @retval 0: Correct
  *         -1: Error
  */
int32_t HexStr2Int(uint8_t *inputstr, uint32_t *intnum)
{
    uint32_t i = 0, res = 0;
    uint32_t val = 0, enEspacioInicial;

    enEspacioInicial = 1;
    if (inputstr[0] == '\0')
        return 0;
    for (i = 0; i < 11; i++)
    {
        if (inputstr[i] == '\0')
            {
            *intnum = val;
            /* return 1; */
            res = 0;
            break;
            }
        if (enEspacioInicial && inputstr[i]==' ')
            continue;
        enEspacioInicial = 0;
        if (ISVALIDHEX(inputstr[i]))
        {
            val = (val << 4) + CONVERTHEX(inputstr[i]);
        }
        else
        {
            /* return 0, Invalid input */
            res = -1;
            break;
        }
    }
    /* over 8 digit hex --invalid */
    if (i >= 11)
    {
      res = -2;
    }
    return res;
}


int32_t HexStrN2Int(uint8_t *inputstr, uint32_t numDigits, uint32_t *intnum)
{
    uint32_t i = 0, res = 0;
    uint32_t val = 0, enEspacioInicial;
    if (inputstr[0] == '\0')
        return 0;
    enEspacioInicial = 1;
    for (i = 0; i < numDigits; i++)
    {
        if (inputstr[i] == '\0' || i > numDigits)
            {
            *intnum = val;
            res = 0;
            break;
            }
        if (enEspacioInicial && inputstr[i]==' ')
            continue;
        enEspacioInicial = 0;
        if (ISVALIDHEX(inputstr[i]))
        {
            val = (val << 4) + CONVERTHEX(inputstr[i]);
        }
        else
        {
            /* return 0, Invalid input */
            res = -1;
            break;
        }
    }
    /* over 8 digit hex --invalid */
    if (i >= 11)
    {
        res = -2;
    }
    *intnum = val;
    return res;
}

int32_t Str2Int(uint8_t *inputstr, uint32_t *intnum)
{
    uint32_t i = 0, res = 0;
    uint32_t val = 0, enEspacioInicial;

    enEspacioInicial = 1;
    for (i = 0;i < 11;i++)
    {
        if (inputstr[i] == '\0')
        {
            *intnum = val;
            /* return 1 */
            res = 0;
            break;
        }
        if (enEspacioInicial && inputstr[i]==' ')
            continue;
        enEspacioInicial = 0;
        if (ISVALIDDEC(inputstr[i]))
        {
            val = val * 10 + CONVERTDEC(inputstr[i]);
        }
        else
        {
            /* return 0, Invalid input */
            res = -1;
            break;
        }
    }
    /* Over 10 digit decimal --invalid */
    if (i >= 11)
    {
      res = -2;
    }
    return res;
}
