/* mezclas.c
 *
 *  Created on: 27/03/2013
 *      Author: joaquin
 */
#include "ch.h"
#include "hal.h"

extern int16_t aleronIzqUp, aleronIzqMed, aleronIzqDwn, aleronDerUp, aleronDerMed, aleronDerDwn;
extern int16_t aleronRCIzq, aleronRCMed, aleronRCDer;
extern int16_t flapsIzqUp, flapsIzqMed, flapsIzqDwn, flapsDerUp, flapsDerMed, flapsDerDwn, porcCrown;
extern int16_t flapsRCUp, flapsRCMed, flapsRCDwn;
extern int16_t aleronMin, aleronMax, flapsMin, flapsMax;

int32_t outServoIzq, outServoDer;
int32_t outFlapsServoIzq, outFlapsServoDer;

void recalAleron(int16_t aleron, int16_t flaps)
{
	int32_t desplazamientoIzd, desplazamientoDer, recorrRestanteIzd, recorrRestanteDer;
	int32_t flapsLimitados;
	flapsLimitados = flaps;
	if ((flapsRCMed-flaps)*(flapsRCUp-flapsRCMed)<0) // el flaps esta por encima del flaps medio
		flapsLimitados = flapsRCMed;
	desplazamientoIzd = (int32_t) (flapsLimitados-flapsRCMed)*porcCrown*(aleronIzqUp-aleronIzqMed);
	desplazamientoIzd /= 100*(flapsRCDwn-flapsRCMed);
	desplazamientoDer = (int32_t) (flapsLimitados-flapsRCMed)*porcCrown*(aleronDerUp-aleronDerMed);
	desplazamientoDer /= 100*(flapsRCDwn-flapsRCMed);
	if ((aleron-aleronRCMed)*(aleronRCIzq-aleronRCMed)>0) // girando a izquierdas
	{
		// aleron izquierdo
		recorrRestanteIzd = (aleronIzqUp - aleronIzqMed-desplazamientoIzd)*(aleron - aleronRCMed);
		recorrRestanteIzd /= (aleronRCIzq - aleronRCMed);
		outServoIzq = aleronIzqMed + desplazamientoIzd + recorrRestanteIzd;
		// aleron derecho
		recorrRestanteDer = (aleronDerDwn - aleronDerMed-desplazamientoDer)*(aleron - aleronRCMed);
		recorrRestanteDer /= (aleronRCIzq - aleronRCMed);
		outServoDer = aleronDerMed + desplazamientoDer + recorrRestanteDer;
	}
	else
	{  // girando a derechas
		// aleron izquierdo
		recorrRestanteIzd = (aleronIzqDwn - aleronIzqMed-desplazamientoIzd)*(aleron - aleronRCMed);
		recorrRestanteIzd /= (aleronRCDer - aleronRCMed);
		outServoIzq = aleronIzqMed + desplazamientoIzd + recorrRestanteIzd;
		// aleron derecho
		recorrRestanteDer = (aleronDerUp - aleronDerMed-desplazamientoDer)*(aleron - aleronRCMed);
		recorrRestanteDer /= (aleronRCDer - aleronRCMed);
		outServoDer = aleronDerMed + desplazamientoDer + recorrRestanteDer;
	}

	if ((flapsRCMed-flaps)*(flapsRCUp-flapsRCMed)<0) // el flaps esta por encima del flaps medio
	{
		outFlapsServoIzq = (flapsIzqUp-flapsIzqMed)*(flaps-flapsRCMed);
		outFlapsServoIzq /= (flapsRCUp - flapsRCMed);
		outFlapsServoIzq += flapsIzqMed;
		outFlapsServoDer = (flapsDerUp-flapsDerMed)*(flaps-flapsRCMed);
		outFlapsServoDer /= (flapsRCUp - flapsRCMed);
		outFlapsServoDer += flapsDerMed;
	}
	else
	{
		outFlapsServoIzq = (flapsIzqDwn-flapsIzqMed)*(flaps-flapsRCMed);
		outFlapsServoIzq /= (flapsRCDwn - flapsRCMed);
		outFlapsServoIzq += flapsIzqMed;
		outFlapsServoDer = (flapsDerDwn-flapsDerMed)*(flaps-flapsRCMed);
		outFlapsServoDer /= (flapsRCDwn - flapsRCMed);
		outFlapsServoDer += flapsDerMed;
	}


	if (outServoIzq<aleronMin) outServoIzq = aleronMin;
	if (outServoIzq>aleronMax) outServoIzq = aleronMax;
	if (outServoDer<aleronMin) outServoDer = aleronMin;
	if (outServoDer>aleronMax) outServoDer = aleronMax;
	/*
	 *   Salida Aleron Izq: TIM4CH1 (PWM1, PB6, Pin-42)
	 *   Salida Aleron Der: TIM4CH2 (PWM2, PB7, Pin-43)
	 *   Salida Flaps Izq:  TIM4CH3 (PWM5, PB8,  Pin-45)
	 *   Salida Flaps Der:  TIM4CH4 (PWM6, PB9,  Pin-46)
	 */
	pwmEnableChannel(&PWMD4, 0, outServoIzq);
	pwmEnableChannel(&PWMD4, 1, outServoDer);
	pwmEnableChannel(&PWMD4, 2, outFlapsServoIzq);
	pwmEnableChannel(&PWMD4, 3, outFlapsServoDer);
}
