/*
 * watchdog.h
 *
 *  Created on: 12/12/2015
 *      Author: joaquin
 */

#ifndef WATCHDOG_H_
#define WATCHDOG_H_

void arrancaReavivaWatchDog(void);
void arrancaWatchDog(void);

#endif /* WATCHDOG_H_ */
