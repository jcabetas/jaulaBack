/*
 * pwmInts.c
 *
 *  Created on: 03/06/2012, adaptado 15/11/2015 a Flip32
 *      Author: joaquin
 *  Entrada aleron  (RC_CH5, Pin-16, TIM3_CH1)
 *  Entrada flaps   (RC_CH6, Pin-17, TIM3_CH2)
 *  Salida Aleron-1 (PWM1,   Pin-29, TIM1_CH1)
 *  Salida Aleron-2 (PWM2,   Pin-32, TIM1_CH4)
 *  Salida Flaps-1  (PWM5,   Pin-45, TIM4_CH3)
 *  Salida Flaps-2  (PWM6,   Pin-46, TIM4_CH4)
 */

#include "hal.h"
#include "chprintf.h"

icucnt_t last_widthTIMAleron;
icucnt_t last_widthTIMFlaps;
int16_t flaps, aleron;
extern int16_t aleronMin, aleronMax, flapsMin, flapsMax, aleronMed;
event_source_t esCalculaAleron, esCalculaFlaps;
mutex_t MtxRecalAleron;

extern uint16_t printPWM;
extern BaseSequentialStream *tty1;

void recalAleron(int16_t aleron, int16_t flaps);


static PWMConfig pwmcfg = {
  3000000, /* 36 MHz PWM clock frequency */
    60000,   /* PWM period 20 millisecond */
  NULL,  /* No callback */
  /* Channel 1 a 4 enabled */
  {
    {PWM_OUTPUT_ACTIVE_HIGH, NULL},
    {PWM_OUTPUT_ACTIVE_HIGH, NULL},
    {PWM_OUTPUT_ACTIVE_HIGH, NULL},
    {PWM_OUTPUT_ACTIVE_HIGH, NULL},
  },
  0,
  0
};

static THD_WORKING_AREA(waThreadPrintPWM, 256);
static THD_FUNCTION(ThreadPrintPWM, arg) {
	(void) arg;
	uint16_t aleronPWM, flapsPWM;
	chRegSetThreadName("printpwm");
	do {
		// wait until ordered to print
		while (printPWM != 1)
			osalThreadSleepMilliseconds(300);
			// copio variables
		chMtxLock(&MtxRecalAleron);
		aleronPWM = aleron;
		flapsPWM = flaps;
		chMtxUnlock(&MtxRecalAleron);
		// imprimo
		chprintf(tty1, "Aileron: %4d us,  flaps: %4d us\r", aleronPWM/3, flapsPWM/3);
		osalThreadSleepMilliseconds(300);
	} while (TRUE);
}

/*
 * Flaps calculo thread
 */
static THD_WORKING_AREA(waThreadFlaps, 128);
static THD_FUNCTION(ThreadFlaps, arg) {
	(void)arg;
	event_listener_t elCalculaFlaps;
	int16_t lastFlaps = 0;
	chEvtGetAndClearFlags(&elCalculaFlaps);
	chEvtRegisterMask(&esCalculaFlaps, &elCalculaFlaps, EVENT_MASK(1));
	chRegSetThreadName("flaps");
	while (TRUE) {
	    chEvtWaitOne(ALL_EVENTS);
		lastFlaps = flaps;
		flaps = last_widthTIMFlaps;
//		if (flaps<flapsMin) flaps = flapsMin;
//		if (flaps>flapsMax) flaps = flapsMax;
		if (flaps!=lastFlaps)
		{
			chMtxLock(&MtxRecalAleron);
			recalAleron(aleron, flaps);
			chMtxUnlock(&MtxRecalAleron);
		}
	}
}

/*
 * Aleron calculo thread
 */
static THD_WORKING_AREA(waThreadAleron, 128);
static THD_FUNCTION(ThreadAleron, arg) {
	(void)arg;
	event_listener_t elCalculaAleron;
	chRegSetThreadName("aleron");
	chEvtGetAndClearFlags(&elCalculaAleron);
	chEvtRegisterMask(&esCalculaAleron, &elCalculaAleron, EVENT_MASK(1));
	while (TRUE) {
		chEvtWaitOne(ALL_EVENTS);
		aleron = last_widthTIMAleron;
//		if (aleron<aleronMin) aleron = aleronMin;
//		if (aleron>aleronMax) aleron = aleronMax;
        chMtxLock(&MtxRecalAleron);
		recalAleron(aleron, flaps);
		chMtxUnlock(&MtxRecalAleron);
	}
}

// Aleron input
static void icuwidthcbTIMAleron(ICUDriver *icup) {
  last_widthTIMAleron = icuGetWidthX(icup);
  chSysLockFromISR();
  if (chEvtIsListeningI(&esCalculaAleron))
  {
      chEvtBroadcastI(&esCalculaAleron);
  }
  chSysUnlockFromISR();
}

static void icuwidthcbTIMFlaps(ICUDriver *icup) {
  last_widthTIMFlaps = icuGetWidthX(icup);
  chSysLockFromISR();
  if (chEvtIsListeningI(&esCalculaFlaps))
  {
      chEvtBroadcastI(&esCalculaFlaps);
  }
  chSysUnlockFromISR();
}

/* Aleron input, TIM2_CH1 */
static ICUConfig icucfgAleron = {
  ICU_INPUT_ACTIVE_HIGH,
  3000000,                                    /* 3 MHz ICU clock frequency (1 ms=>3000 cuentas)  */
  icuwidthcbTIMAleron,
  NULL,
  NULL,
  ICU_CHANNEL_1,
  0
};

/* Flaps input, TIM3_CH1 */
static ICUConfig icucfgFlaps = {
  ICU_INPUT_ACTIVE_HIGH,
  3000000,                                    /* 3 MHz ICU clock frequency.   */
  icuwidthcbTIMFlaps,
  NULL,
  NULL,
  ICU_CHANNEL_1,
  0
};

void initServo(void)
{
	last_widthTIMAleron = last_widthTIMFlaps = 0;
	/*
 * 	 InputAleron: TIM2CH1 (RC1, Pin-10, PA0)
 * 	 InputFlaps:  TIM3CH1 (RC5, Pin-16, PA6)
	*/
	chMtxObjectInit(&MtxRecalAleron);
	chEvtObjectInit(&esCalculaAleron);
	chEvtObjectInit(&esCalculaFlaps);
	chThdCreateStatic(waThreadFlaps, sizeof(waThreadFlaps), NORMALPRIO, ThreadFlaps, NULL);
	chThdCreateStatic(waThreadAleron, sizeof(waThreadAleron), NORMALPRIO, ThreadAleron, NULL);

	icuStart(&ICUD2, &icucfgAleron);
	icuStartCapture(&ICUD2);
	icuEnableNotifications(&ICUD2);
	icuStart(&ICUD3, &icucfgFlaps);
	icuStartCapture(&ICUD3);
	icuEnableNotifications(&ICUD3);
/*
 *   Salida Aleron Izq: TIM4CH1 (PWM3, PB6, Pin-42)
 *   Salida Aleron Der: TIM4CH2 (PWM4, PB7, Pin-43)
 *   Salida Flaps Izq:  TIM4CH3 (PWM5, PB8,  Pin-45)
 *   Salida Flaps Der:  TIM4CH4 (PWM6, PB9,  Pin-46)
 */
	palSetPadMode(IOPORT2, 6, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
	palSetPadMode(IOPORT2, 7, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
	palSetPadMode(IOPORT2, 8, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
	palSetPadMode(IOPORT2, 9, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
	pwmStart(&PWMD4, &pwmcfg);
	chThdCreateStatic(waThreadPrintPWM, sizeof(waThreadPrintPWM), NORMALPRIO+1, ThreadPrintPWM, NULL);
}


