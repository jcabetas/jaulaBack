/*
 * sbus.c
 *
 *  Created on: 9/11/2015
 *      Author: joaquin
 */

#include "hal.h"
#include "chprintf.h"

extern BaseSequentialStream *tty1;

// #define SD_PARITY_ERROR         (eventflags_t)32    /**< @brief Parity.     */
// #define SD_FRAMING_ERROR        (eventflags_t)64    /**< @brief Framing.    */
// #define SD_OVERRUN_ERROR        (eventflags_t)128   /**< @brief Overflow.   */
// #define SD_NOISE_ERROR          (eventflags_t)256   /**< @brief Line noise. */
// #define SD_BREAK_DETECTED       (eventflags_t)512   /**< @brief LIN Break.  */
// CHN_OUTPUT_EMPTY
// CHN_TRANSMISSION_END
// CHN_INPUT_AVAILABLE

 /*
 * I2C thread
 */

// debug data
uint16_t buffer[100], posBuffer, sbus[50];
extern uint16_t printSBUS;
extern mutex_t mtxSBUS;

/*
 * decode sbus. Returns 1 on error, 0 on success
 */
uint8_t frame2sbus(void)
{
	chMtxLock(&mtxSBUS);
	sbus[0]  = ((buffer[1]    |buffer[2]<<8)                 & 0x07FF);
	sbus[1]  = ((buffer[2]>>3 |buffer[3]<<5)                 & 0x07FF);
	sbus[2]  = ((buffer[3]>>6 |buffer[4]<<2 |buffer[5]<<10)  & 0x07FF);
	sbus[3]  = ((buffer[5]>>1 |buffer[6]<<7)                 & 0x07FF);
	sbus[4]  = ((buffer[6]>>4 |buffer[7]<<4)                 & 0x07FF);
	sbus[5]  = ((buffer[7]>>7 |buffer[8]<<1 |buffer[9]<<9)   & 0x07FF);
	sbus[6]  = ((buffer[9]>>2 |buffer[10]<<6)                & 0x07FF);
	sbus[7]  = ((buffer[10]>>5|buffer[11]<<3)                & 0x07FF);
	sbus[8]  = ((buffer[12]   |buffer[13]<<8)                & 0x07FF);
	sbus[9]  = ((buffer[13]>>3|buffer[14]<<5)                & 0x07FF);
	sbus[10] = ((buffer[14]>>6|buffer[15]<<2|buffer[16]<<10) & 0x07FF);
	sbus[11] = ((buffer[16]>>1|buffer[17]<<7)                & 0x07FF);
	sbus[12] = ((buffer[17]>>4|buffer[18]<<4)                & 0x07FF);
	sbus[13] = ((buffer[18]>>7|buffer[19]<<1|buffer[20]<<9)  & 0x07FF);
	sbus[14] = ((buffer[20]>>2|buffer[21]<<6)                & 0x07FF);
	sbus[15] = ((buffer[21]>>5|buffer[22]<<3)                & 0x07FF);
	chMtxUnlock(&mtxSBUS);
	return 0;
}


static THD_WORKING_AREA(waThreadPrintSBUS, 256);
static THD_FUNCTION(ThreadPrintSBUS, arg) {
	(void) arg;
	uint16_t sbusCopy[50],i;
	chRegSetThreadName("printsbus");
	do {
		// wait until ordered to print
		while (printSBUS != 1)
			osalThreadSleepMilliseconds(300);
			// copio variables
		chMtxLock(&mtxSBUS);
		for (i=0;i<15;i++)
			sbusCopy[i] = sbus[i];
		chMtxUnlock(&mtxSBUS);
		// imprimo
		for (i = 0; i < 15; i++)
			chprintf(tty1, "%4d ", sbusCopy[i]);
		chprintf(tty1, "\r");
		osalThreadSleepMilliseconds(300);
	} while (TRUE);
}


static THD_WORKING_AREA(waThreadSBUS,256);
static THD_FUNCTION(ThreadSBUS, arg) {
	(void) arg;
	chRegSetThreadName("sbus");

	msg_t charbuf;
	uint8_t posBuffer; //0 esperando time-out, 1 leyendo, 2 fin de trama


	// wait for timeout
	do {
		charbuf = chnGetTimeout(&SD2, TIME_IMMEDIATE);
	}	while (charbuf != Q_TIMEOUT);

	// lee tramas
	do {
		posBuffer = 0;
		do {
			charbuf = chnGetTimeout(&SD2, MS2ST(1));
			if (charbuf != Q_TIMEOUT)
				buffer[posBuffer++] = (uint8_t)charbuf;
			else
				posBuffer = 0;
		} while (posBuffer<25);
		frame2sbus();
	} while (TRUE);
}

static SerialConfig sbus_serial_cfg = {
	100000,
	USART_CR1_M | USART_CR1_PCE, // even parity
	USART_CR2_STOP_1, // 2 bits de stop
	0
};


void arrancaSBUS(void)
{
    // Activates the Serial driver 2, PA2(TX) and PA3(RX) are routed to USART2, 9600 8N1.
    sdStart(&SD2, &sbus_serial_cfg);
	chThdCreateStatic(waThreadSBUS, sizeof(waThreadSBUS), NORMALPRIO+1, ThreadSBUS, NULL);
	chThdCreateStatic(waThreadPrintSBUS, sizeof(waThreadPrintSBUS), NORMALPRIO+1, ThreadPrintSBUS, NULL);
}







