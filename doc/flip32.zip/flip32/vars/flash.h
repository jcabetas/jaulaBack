/*
 * flash.h
 *
 *  Created on: 27/03/2013
 *      Author: joaquin
 */

#ifndef FLASH_H_
#define FLASH_H_

void programaHalfWord(uint16_t *direccion, uint16_t valor);
void borraPagina(uint32_t address);

#define StartAddrPlc  ((uint32_t) 0x0801D000)
#define EndAddrPlc    ((uint32_t) 0x0801EFFF)
#define StartAddrVar  ((uint32_t) 0x0801F000)
#define EndAddrVar    ((uint32_t) 0x0801FFFF)
#define PageSize   ((uint32_t)0x400)

#endif /* FLASH_H_ */
