#include <ch.h>
#include <hal.h>

#include "board.h"
#include "serial.h"
#include "tty.h"
#include "flash.h"
#include "vars.h"
#include "chprintf.h"
#include "math.h"

extern BaseSequentialStream *tty1;
extern uint8_t errorVars;

int16_t aleronIzqUp, aleronIzqMed, aleronIzqDwn, aleronDerUp, aleronDerMed, aleronDerDwn;
int16_t aleronRCIzq, aleronRCMed, aleronRCDer;
int16_t flapsIzqUp, flapsIzqMed, flapsIzqDwn, flapsDerUp, flapsDerMed, flapsDerDwn, porcCrown;
int16_t flapsRCUp, flapsRCMed, flapsRCDwn;
int16_t aleronMin, aleronMax, flapsMin, flapsMax;
int16_t valores[20];

extern int16_t flaps, aleron;
extern int32_t outServoIzq, outServoDer;
extern int32_t outFlapsServoIzq, outFlapsServoDer;

extern icucnt_t last_widthTIMAleron;
extern icucnt_t last_widthTIMFlaps;

//  0            1             2             3            4             5
//  aleronIzqUp, aleronIzqMed, aleronIzqDwn, aleronDerUp, aleronDerMed, aleronDerDwn;
//  6            7            8
//  aleronRCIzq, aleronRCMed, aleronRCDer;
//  9           10           11           12          13           14
//  flapsIzqUp, flapsIzqMed, flapsIzqDwn, flapsDerqUp, flapsDerMed, flapsDerDwn
//  15          16          17
//  flapsRCUp, flapsRCMed, flapsRCDwn;
//  18
//  porcCrown;

void ponMaxyMin(void)
{
	// calculo valores limites
	if (aleronRCIzq<aleronRCDer)
	{
		aleronMin = aleronRCIzq;
		aleronMax = aleronRCDer;
	}
	else
	{
		aleronMin = aleronRCDer;
		aleronMax = aleronRCIzq;
	}
	if (flapsRCUp<flapsRCDwn)
	{
		flapsMin = flapsRCUp;
		flapsMax = flapsRCDwn;
	}
	else
	{
		flapsMin = flapsRCDwn;
		flapsMax = flapsRCUp;
	}
	outServoIzq = aleronIzqMed;
	outServoDer = aleronDerMed;
	outFlapsServoIzq = flapsIzqMed;
	outFlapsServoDer = flapsDerMed;
}

void copyValores2Data(void)
{
	// copy buffer to actual data
	aleronIzqUp = valores[0];
	aleronIzqMed = valores[1];
	aleronIzqDwn = valores[2];
	aleronDerUp = valores[3];
	aleronDerMed = valores[4];
	aleronDerDwn = valores[5];
	aleronRCIzq = valores[6];
	aleronRCMed = valores[7];
	aleronRCDer = valores[8];
	flapsIzqUp = valores[9];
	flapsIzqMed = valores[10];
	flapsIzqDwn = valores[11];
	flapsDerUp = valores[12];
	flapsDerMed = valores[13];
	flapsDerDwn = valores[14];
	flapsRCUp = valores[15];
	flapsRCMed = valores[16];
	flapsRCDwn = valores[17];
	porcCrown = valores[18];
	ponMaxyMin();
}

void copyData2Valores(void)
{
	// copy actual data to buffer
	valores[0] = aleronIzqUp;
	valores[1] = aleronIzqMed;
	valores[2] = aleronIzqDwn;
	valores[3] = aleronDerUp;
	valores[4] = aleronDerMed;
	valores[5] = aleronDerDwn;
	valores[6] = aleronRCIzq;
	valores[7] = aleronRCMed;
	valores[8] = aleronRCDer;
	valores[9] = flapsIzqUp;
	valores[10] = flapsIzqMed;
	valores[11] = flapsIzqDwn;
	valores[12] = flapsDerUp;
	valores[13] = flapsDerMed;
	valores[14] = flapsDerDwn;
	valores[15] = flapsRCUp;
	valores[16] = flapsRCMed;
	valores[17] = flapsRCDwn;
	valores[18] = porcCrown;
}



void printAjustes(void)
{
	chprintf(tty1,"                 UP   CENTER    DOWN\n\r");
	chprintf(tty1,"  Aileron left  %4d .. %4d .. %4d\r\n", aleronIzqUp/3, aleronIzqMed/3, aleronIzqDwn/3);
	chprintf(tty1,"  Aileron right %4d .. %4d .. %4d\r\n", aleronDerUp/3, aleronDerMed/3, aleronDerDwn/3);
	chprintf(tty1,"  Flaps left    %4d .. %4d .. %4d\r\n", flapsIzqUp/3, flapsIzqMed/3, flapsIzqDwn/3);
	chprintf(tty1,"  Flaps right   %4d .. %4d .. %4d\r\n", flapsDerUp/3, flapsDerMed/3, flapsDerDwn/3);
	chprintf(tty1,"  Crow percentage: %d %%\r\n", porcCrown);
}



void leeAjustesDeFlash(void)
{
	//  0            1             2             3            4             5
	//  aleronIzqUp, aleronIzqMed, aleronIzqDwn, aleronDerUp, aleronDerMed, aleronDerDwn;
	//  6            7            8
	//  aleronRCIzq, aleronRCMed, aleronRCDer;
	//  9           10           11           12          13           14
	//  flapsIzqUp, flapsIzqMed, flapsIzqDwn, flapsDerqUp, flapsDerMed, flapsDerDwn
	//  15          16          17
	//  flapsRCUp, flapsRCMed, flapsRCDwn;
	//  18
	//  porcCrown;
	int error, errorLectura=0;
	aleronIzqUp =  leeVariable2bytes(0, 2980, &error); if (error!=0) errorLectura = 1;
	aleronIzqMed = leeVariable2bytes(1, 4529, &error); if (error!=0) errorLectura = 1;
	aleronIzqDwn = leeVariable2bytes(2, 6068, &error); if (error!=0) errorLectura = 1;
	aleronDerUp =  leeVariable2bytes(3, 6068, &error); if (error!=0) errorLectura = 1;
	aleronDerMed = leeVariable2bytes(4, 4529, &error); if (error!=0) errorLectura = 1;
	aleronDerDwn = leeVariable2bytes(5, 2980, &error); if (error!=0) errorLectura = 1;
	aleronRCIzq =  leeVariable2bytes(6, 2980, &error); if (error!=0) errorLectura = 1;
	aleronRCMed = leeVariable2bytes(7, 4529, &error); if (error!=0) errorLectura = 1;
	aleronRCDer = leeVariable2bytes(8, 6068, &error); if (error!=0) errorLectura = 1;
	flapsIzqUp = leeVariable2bytes(9, 5753, &error); if (error!=0) errorLectura = 1;
	flapsIzqMed = leeVariable2bytes(10, 5451, &error); if (error!=0) errorLectura = 1;
	flapsIzqDwn = leeVariable2bytes(11, 3281, &error); if (error!=0) errorLectura = 1;
	flapsDerUp = leeVariable2bytes(12, 5753, &error); if (error!=0) errorLectura = 1;
	flapsDerMed = leeVariable2bytes(13, 5451, &error); if (error!=0) errorLectura = 1;
	flapsDerDwn = leeVariable2bytes(14, 3281, &error); if (error!=0) errorLectura = 1;
	flapsRCUp =  leeVariable2bytes(15, 5753, &error); if (error!=0) errorLectura = 1;
	flapsRCMed = leeVariable2bytes(16, 5451, &error); if (error!=0) errorLectura = 1;
	flapsRCDwn = leeVariable2bytes(17, 3281, &error); if (error!=0) errorLectura = 1;
	porcCrown = leeVariable2bytes(18, 40, &error); if (error!=0) errorLectura = 1;
	if (errorLectura!=0)
	{
		errorVars = 1;
		chprintf(tty1,"Error when reading data (run 'adjust')\r\n");
	}
	else
		errorVars = 0;
	ponMaxyMin();
}

int16_t ajustaValor(char *msg, icucnt_t *ptrVal)
{
	int16_t valorMin, valorMax, numMuestras, valor, valorMedio, i;
	int32_t sumaValores;
    valorMin = 0x7FFF;
    valorMax = 0;
    sumaValores = 0;
    numMuestras = 0;
	chprintf(tty1,"%s and hit 'CR'\r\n", msg);
	chgetch();
    for (i=0;i<128;i++)
    {
    	valor = (int16_t) *ptrVal;
    	chprintf(tty1,"%6d\r",valor/3);
    	if (valor>valorMax) valorMax = valor;
    	if (valor<valorMin) valorMin = valor;
    	sumaValores += valor;
    	numMuestras++;
        chThdSleepMilliseconds(20);
    }
    valorMedio = (int16_t) (sumaValores/numMuestras);
    chprintf(tty1,"%s min.:%d  average:%d  max.:%d\r\n", msg, valorMin/3, valorMedio/3, valorMax/3);
    return valorMedio;
}

// devuelve 1 si ha habido cambios
uint8_t ajustaValorFino(void)
{
	uint8_t servo, parametro,numValor, up, value, cambios = 0;
	do {
		do {
			chprintf(tty1,"Select a servo to adjust:\r\n");
			chprintf(tty1,"1: Left aileron\r\n");
			chprintf(tty1,"2: Right aileron\r\n");
			chprintf(tty1,"3: Left flap\r\n");
			chprintf(tty1,"4: Right flap\r\n");
			chprintf(tty1,"0: Quit\r\n");
			servo = chgetch();
			chprintf(tty1,"%c\r\n",servo);
		} while (servo<'0' && servo>'4');
		if (servo=='0') return cambios;
		do {
			do {
				chprintf(tty1,"Parameter to adjust:\r\n");
				chprintf(tty1,"1: Up position\r\n");
				chprintf(tty1,"2: Mid position\r\n");
				chprintf(tty1,"3: Down\r\n");
				chprintf(tty1,"0: Quit\r\n");
				parametro = chgetch();
				chprintf(tty1,"%c\r\n",parametro);
			} while (parametro<'0' && parametro>'3');
			if (parametro == '0') break;
			if (servo=='1' && parametro>='1' && parametro<='3') numValor = parametro-'1'; 		// left aleron: de 0 a 2
			if (servo=='2' && parametro>='1' && parametro<='3') numValor = 3 + parametro-'1'; 	// right aleron: de 3 a 5
			if (servo=='3' && parametro>='1' && parametro<='3') numValor = 9 + parametro-'1'; 	// left flaps: de 9 a 11
			if (servo=='4' && parametro>='1' && parametro<='3') numValor = 12 + parametro-'1'; 	// right flaps: de 12 a 14
			up = 1;
			chprintf(tty1,"i: Increment, d: Decrement, 1..9: value, 0: Quit\r\n");
			do {
				value = chgetch();
				if (value == '0') break;
				if (value == 'i') up = 1;
				if (value == 'd') up = 0;
				if (value >= '1' && value<='9')
				{
					if (up)
						valores[numValor] += value - '0';
					else
						valores[numValor] -= value - '0';
					cambios = 1;
					copyValores2Data();
				}
			} while (TRUE); // bucle de ajuste +-
		} while (TRUE); // parametro a ajustar
	} while (TRUE); // select servo
}


void ajustaRadio(void)
{
	uint8_t opcionRC, *bufferEnt, cambiadoRC = 0, cambiadoCrow = 0, hayCambios;
	uint32_t variable;
	int32_t ok;
	int i, error = 0;

	copyData2Valores();
	// print actual data
	chprintf(tty1,"Actual data:\n\r");
	printAjustes();
	do
	{
		// adjust RC values

		//  0            1             2             3            4             5
		//  aleronIzqUp, aleronIzqMed, aleronIzqDwn, aleronDerUp, aleronDerMed, aleronDerDwn;
		//  6            7            8
		//  aleronRCIzq, aleronRCMed, aleronRCDer;
		//  9           10           11           12          13           14
		//  flapsIzqUp, flapsIzqMed, flapsIzqDwn, flapsDerqUp, flapsDerMed, flapsDerDwn
		//  15          16          17
		//  flapsRCUp, flapsRCMed, flapsRCDwn;
		//  18
		//  porcCrown;

		chprintf(tty1,"\n\rLast data (us):\n\r");
		chprintf(tty1,"                 UP  CENTER   DOWN\n\r");
		chprintf(tty1,"  Aileron left  %4d .. %4d .. %4d\r\n", valores[0]/3, valores[1]/3, valores[2]/3);
		chprintf(tty1,"  Aileron right %4d .. %4d .. %4d\r\n", valores[3]/3, valores[4]/3, valores[5]/3);
		chprintf(tty1,"  RC aile. left %4d    %4d .. %4d right\r\n", valores[6]/3, valores[7]/3, valores[8]/3);
		chprintf(tty1,"  Flaps left    %4d .. %4d .. %4d\r\n", valores[9]/3, valores[10]/3, valores[11]/3);
		chprintf(tty1,"  Flaps right   %4d .. %4d .. %4d\r\n", valores[12]/3, valores[13]/3, valores[14]/3);
		chprintf(tty1,"  RC flaps left %4d    %4d .. %4d right\r\n", valores[15]/3, valores[16]/3, valores[17]/3);
		chprintf(tty1,"  Crow factor(%%) %3d\r\n", valores[18]);
		chprintf(tty1,"\n\r");
		chprintf(tty1,"1: Adjust RC values\n\r");
		chprintf(tty1,"2: Servo invertion\n\r");
		chprintf(tty1,"3: Crow factor\n\r");
		chprintf(tty1,"4: Fine adjustment\n\r");
		chprintf(tty1,"5: Save and use new values\n\r");
		if (cambiadoRC || cambiadoCrow)
			chprintf(tty1,"0: Quit losing adjustments\n\r");
		else
			chprintf(tty1,"0: Quit\n\r");
		chprintf(tty1,"Option: ");
		opcionRC = chgetch();
		chprintf(tty1,"%c\r\n",opcionRC);
		if (opcionRC == '1')
		{
			valores[0] = valores[5] = valores[6] = ajustaValor("move aileron top left", &last_widthTIMAleron);
			valores[1] = valores[4] = valores[7] = ajustaValor("center aileron", &last_widthTIMAleron);
			valores[2] = valores[3] = valores[8] = ajustaValor("move aileron top right", &last_widthTIMAleron);
			valores[9] = valores[12] = valores[15] = ajustaValor("flaps up position", &last_widthTIMFlaps);
			valores[10] = valores[13] = valores[16] = ajustaValor("flaps med position (to start crow mix)", &last_widthTIMFlaps);
			valores[11] = valores[14] = valores[17] = ajustaValor("flaps down position", &last_widthTIMFlaps);
			cambiadoRC = 1;
			continue;
		}
		if (opcionRC == '2')
		{
			uint8_t invert;
			chprintf(tty1,"Invert left aileron (1 == yes): ");
			invert = chgetch();
			chprintf(tty1,"%c\r\n",invert);
			if (invert == '1')
			{
				uint16_t valor = valores[0];
				valores[0] = valores[2];
				valores[2] = valor;
			}
			chprintf(tty1,"Invert right aileron (1 == yes): ");
			invert = chgetch();
			chprintf(tty1,"%c\r\n",invert);
			if (invert == '1')
			{
				uint16_t valor = valores[3];
				valores[3] = valores[5];
				valores[5] = valor;
			}
			chprintf(tty1,"Invert left flap (1 == yes): ");
			invert = chgetch();
			chprintf(tty1,"%c\r\n",invert);
			if (invert == '1')
			{
				uint16_t difUp2Cent = valores[9] - valores[10]; // diferencia Up-Center
				uint16_t valor = valores[9]; // antiguo up
				valores[9] = valores[11];
				valores[10] = valores[11] + difUp2Cent;
				valores[11] = valor;
			}
			chprintf(tty1,"Invert right flap (1 == yes): ");
			invert = chgetch();
			chprintf(tty1,"%c\r\n",invert);
			if (invert == '1')
			{
				uint16_t difUp2Cent = valores[12] - valores[13]; // diferencia Up-Center
				uint16_t valor = valores[12];
				valores[12] = valores[14];
				valores[13] = valores[14] + difUp2Cent;
				valores[14] = valor;
			}
			copyValores2Data();
			cambiadoRC = 1;
			continue;
		}
		if (opcionRC == '3')
		{
			do
			{
				chprintf(tty1,"Crow percentage (%%): ");
				bufferEnt = chgets();
				ok = Str2Int(bufferEnt, &variable);
				if (ok != 0)
				{
					chprintf(tty1,"Illegal input (%d interpreted from %s), ok:%d, repeat!! \r\n",variable,bufferEnt,ok);
					continue;
				}
				valores[18] = (uint16_t) variable;
			} while (ok!=0);
			cambiadoCrow = 1;
			continue;
		}
		if (opcionRC == '4')
		{
			hayCambios = ajustaValorFino();
			if (hayCambios) cambiadoRC = 1;
			continue;
		}
		// graba RC data
		if (opcionRC=='5')
		{
			if (errorVars && cambiadoRC && !cambiadoCrow)
				chprintf(tty1,"Crow factor not defined.. storing only RC values!!!\r\n");
			if (cambiadoRC==1)
			{
				// almaceno todos los datos RC
				for (i=0;i<=17;i++)
				{
					escribeVariable2bytes(i,valores[i], &error);
					if (error != 0)
					{
						chprintf(tty1,"Error %d when writing %X at position %X, exiting\r\n",error,valores[i],i);
						return;
					}
				}
				cambiadoRC = 0;
			}
		// graba otros datos
			if (cambiadoCrow==1)
			{
				escribeVariable2bytes(18,valores[18], &error);
				if (error != 0)
				{
					chprintf(tty1,"Error %d when writing %X at position %X, exiting\r\n",error,valores[i],i);
					return;
				}
				cambiadoCrow = 0;
			}
			chprintf(tty1,"Data succesfully stored!\r\n");
			chprintf(tty1,"New data at permanent memory:\n\r");
			leeAjustesDeFlash();

			continue;
		}
		if (opcionRC == '0')
		{
			chprintf(tty1,"Quitting...\r\n");
			leeAjustesDeFlash();
			return;
		}
	} while (TRUE);
}
