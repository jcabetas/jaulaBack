/*
 * menuVars.c
 *
 *  Created on: 27/03/2013
 *      Author: joaquin
 */

#include <ch.h>
#include <hal.h>

#include "board.h"
#include "serial.h"
#include "tty.h"
#include "flash.h"
#include "vars.h"
#include "chprintf.h"

extern BaseSequentialStream *tty1;
/*
 * Ejemplos de prueba variables de la flash

	chprintf(tty1,"Antes de hacer nada: \r\n");
	muestraMemoria();
	leeVariableString(buffer, sizeof(buffer), 1, "Hola joaquin", &error);
	chprintf(tty1,"Al buscar string 1 resulta buffer:'%s' error:%d\r\n",buffer,error);
	escribeVariableString(1, mensaje, sizeof(mensaje), &error);
	chprintf(tty1,"Despues de escribir mensaje con error %d\r\n",error);
	muestraMemoria();
	rastreaVariables();
	leeVariableString(buffer, sizeof(buffer), 1, "Hola joaquin", &error);
	chprintf(tty1,"Al buscar string 1 otra vez resulta buffer:'%s' error:%d\r\n",buffer,error);
	escribeVariableString(1, mensaje, sizeof(mensaje), &error);
	chprintf(tty1,"Despues de escribir el mismo mensaje, error %d\r\n",error);
	muestraMemoria();
	rastreaVariables();
	leeVariableString(buffer, sizeof(buffer), 1, "Hola joaquin", &error);
	chprintf(tty1,"Al buscar string 1 otra vez resulta buffer:'%s' error:%d\r\n",buffer,error);
	escribeVariableString(1, mensaje2, sizeof(mensaje2), &error);
	chprintf(tty1,"Despues de escribir mensaje2 diferente, error %d\r\n",error);
	muestraMemoria();
	rastreaVariables();
	leeVariableString(buffer, sizeof(buffer), 1, "Hola joaquin", &error);
	chprintf(tty1,"Al buscar string 1 otra vez resulta buffer:'%s' error:%d\r\n",buffer,error);
*/

void menuVars(void)
{
    int ok;
    uint32_t i,numVariable,valorVariable,numIniVariable,numVariables,valorInicial;
    uint8_t opcion,*bufferEnt;
    while (1==1)
    {
        chprintf(tty1,"Variables:\r\n");
        chprintf(tty1,"1: Show memory\r\n");
        chprintf(tty1,"2: Look for a variable\r\n");
        chprintf(tty1,"3: Write variable\r\n");
        chprintf(tty1,"4: Write several variables\r\n");
        chprintf(tty1,"5: Erase memory\r\n");
        chprintf(tty1,"0: Return\r\n");
        opcion = chgetch();
        chprintf(tty1,"%c\r\n",opcion);
        if (opcion == '1')
            muestraMemoria();
        if (opcion == '2')
            rastreaVariables();
        if (opcion == '3')
        {
        	chprintf(tty1,"# variable:");
            bufferEnt = chgets();
            ok = Str2Int(bufferEnt, &numVariable);
            if (ok != 0)
            {
            	chprintf(tty1,"Illegal number (%d from %s), ok:%d returning\r\n",numVariable,bufferEnt,ok);
                continue;
            }
            chprintf(tty1,"\r\nValue:");
            bufferEnt = chgets();
            ok = Str2Int(bufferEnt, &valorVariable);
            if (ok != 0 || valorVariable>0xFFFF)
            {
            	chprintf(tty1,"Illegal number, returning\r\n");
                continue;
            }
            escribeVariable2bytes(numVariable,valorVariable, &ok);
            if (ok != 0)
            	chprintf(tty1,"Error %d while writing\r\n",ok);
            else
            	chprintf(tty1,"\r\n");
        }
        if (opcion == '4')
        {
        	chprintf(tty1,"Write variables VarIni..VarIni+NumVars with values Vinicial..Vinicial+10\r\n");
        	chprintf(tty1,"# initial variable:");
            bufferEnt = chgets();
            ok = Str2Int(bufferEnt, &numIniVariable);
            if (ok != 0)
            {
            	chprintf(tty1,"Illegal number, returning\r\n");
                continue;
            }
            chprintf(tty1,"\r\nNumber of variables (max 1000):");
            bufferEnt = chgets();
            ok = Str2Int(bufferEnt, &numVariables);
            if (ok != 0 || numVariables>1000)
            {
            	chprintf(tty1,"Illegal number, returning\r\n");
                continue;
            }
            chprintf(tty1,"\r\nInitial value:");
            bufferEnt = chgets();
            ok = Str2Int(bufferEnt, &valorInicial);
            if (ok != 0)
            {
            	chprintf(tty1,"Illegan number, returning\r\n");
                continue;
            }
            chprintf(tty1,"\r\nWriting variable #%d..%d with values %d..%d\r\n",numIniVariable,numIniVariable+numVariables-1,valorInicial,valorInicial+numVariables-1);
            for (i=numIniVariable;i<numIniVariable+numVariables;i++)
            {
                escribeVariable2bytes(i,i+valorInicial-numIniVariable, &ok);
                if (ok != 0)
                {
                	chprintf(tty1,"Error %d while writing at position %X value %X\r\n",ok,i,i+valorInicial-numIniVariable);
                    break;
                }
            }
        }
        if (opcion == '5')
            borroMemoriaVars();
        if (opcion == '0') break;
        if (opcion < '0' || opcion>'5')
        	chprintf(tty1,"Illegal option\r\n");
    }
}
