/*
 * vars.h
 *
 *  Created on: 27/03/2013
 *      Author: joaquin
 */

#ifndef VARS_H_
#define VARS_H_

void menuVars(void);
void guardaVariablesSistemasEEprom(void);
void leeVariablesSistemas(void);
int leeVariable2bytes(int numPosicion, int valorDefecto, int *error);
void initFrioVariablesSistemas(void);
void muestraMemoria(void);
void rastreaVariables(void);
void escribeVariable2bytes(int numPosicion, int valor, int *error);
void borroMemoriaVars(void);
void ajustaRadio(void);
void leeAjustesDeFlash(void);

#endif /* VARS_H_ */
