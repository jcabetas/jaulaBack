/*
 * flash.c
 *
 *  Created on: 27/03/2013
 *      Author: joaquin
 */


//#include "ch.h"
#undef TRUE
#undef FALSE
#define STM32F10X_MD
#include "stlib/stm32f10x_flash.h"
#include "vars/flash.h"

/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

volatile FLASH_Status FLASHStatus;
volatile TestStatus MemoryProgramStatus;

// prototipos locales



void programaHalfWord(uint16_t *direccion, uint16_t valor)
{
    uint32_t puntDato;
    puntDato = (uint32_t) direccion;
    MemoryProgramStatus = PASSED;
    FLASH_Unlock();
    FLASHStatus = FLASH_ProgramHalfWord(puntDato, valor);
    FLASH_Lock();
}


void borraPagina(uint32_t address)
{
    FLASHStatus = FLASH_COMPLETE;
    MemoryProgramStatus = PASSED;
    FLASH_Unlock();
    FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
    FLASHStatus = FLASH_ErasePage(address);
    FLASH_Lock();
}
