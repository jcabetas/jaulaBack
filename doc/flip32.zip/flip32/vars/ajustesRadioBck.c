#include <ch.h>
#include <hal.h>

#include "board.h"
#include "serial.h"
#include "tty.h"
#include "flash.h"
#include "vars.h"
#include "chprintf.h"

extern BaseSequentialStream *tty1;
extern uint8_t errorVars;

int16_t aleronIzq, aleronDer, flapsArriba, flapsAbajo, porcMezcla, porcDiferen, invIzq, invDer;
int16_t aleronMin, aleronMax, flapsMin, flapsMax, aleronMed;
extern int16_t flaps, aleron;
extern int16_t outServoIzq, outServoDer;

extern icucnt_t last_widthTIMAleron;
extern icucnt_t last_widthTIMFlaps;


void printAjustes(void)
{
	chprintf(tty1,"\n\r");
	chprintf(tty1,"  Aileron  %d ..%d\r\n", aleronIzq, aleronDer);
	chprintf(tty1,"  Flaps   %d ..%d\r\n", flapsArriba, flapsAbajo);
	chprintf(tty1,"  Crow percentage: %d %%\r\n", porcMezcla);
	chprintf(tty1,"  Aileron diff.: %d %%\r\n", porcDiferen);
	chprintf(tty1,"  Invert left aileron: %d   right servo: %d\r\n\r\n", invIzq, invDer);
}


void leeAjustesDeFlash(void)
{
	int error;
	aleronIzq = leeVariable2bytes(0, 3000, &error);
	errorVars = 0;
	if (error!=0)
	{
		chprintf(tty1, "Error %d when reading left aileron (read %d)\r\n", error, aleronIzq);
		errorVars = 1;
	}
	aleronDer = leeVariable2bytes(1, 6000, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading right aileron (read %d)\r\n", error, aleronDer);
		errorVars = 1;
	}
	flapsArriba = leeVariable2bytes(2, 3000, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading up flaps (read %d)\r\n", error, flapsArriba);
		errorVars = 1;
	}
	flapsAbajo = leeVariable2bytes(3, 6000, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading down flaps (read %d)\r\n", error, flapsAbajo);
		errorVars = 1;
	}
	porcMezcla = leeVariable2bytes(4, 0, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading crow percentage (read %d)\r\n", error, porcMezcla);
		errorVars = 1;
	}
	porcDiferen = leeVariable2bytes(5, 0, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading differential (read %d)\r\n", error, porcDiferen);
		errorVars = 1;
	}
	invIzq = leeVariable2bytes(6, 0, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading left servo invert (read %d)\r\n", error, invIzq);
		errorVars = 1;
	}
	invDer = leeVariable2bytes(7, 0, &error);
	if (error!=0)
	{
		chprintf(tty1,"Error %d when reading right servo invert (read %d)\r\n", error, invDer);
		errorVars = 1;
	}
	if (errorVars ==1)
	{
		chprintf(tty1,"NOTE: Error 1 usually means that you have to run adjust procedure!\r\n");
	}

	aleronMed = (aleronIzq+aleronDer)/2;
	if (aleronIzq<aleronDer)
	{
		aleronMin = aleronIzq;
		aleronMax = aleronDer;
	}
	else
	{
		aleronMin = aleronDer;
		aleronMax = aleronIzq;
	}
	if (flapsArriba<flapsAbajo)
	{
		flapsMin = flapsArriba;
		flapsMax = flapsAbajo;
	}
	else
	{
		flapsMin = flapsAbajo;
		flapsMax = flapsArriba;
	}
	flaps = flapsMin;
	aleron = outServoIzq = outServoDer = aleronMed;
}

int16_t ajustaValor(char *msg, icucnt_t *ptrVal)
{
	int16_t valorMin, valorMax, numMuestras, valor, valorMedio, i;
	int32_t sumaValores;
    valorMin = 0x7FFF;
    valorMax = 0;
    sumaValores = 0;
    numMuestras = 0;
	chprintf(tty1,"Move %s and hit 'CR'\r\n", msg);
	chgetch();
    for (i=0;i<128;i++)
    {
    	valor = (int16_t) *ptrVal;
    	chprintf(tty1,"%6d\r",valor);
    	if (valor>valorMax) valorMax = valor;
    	if (valor<valorMin) valorMin = valor;
    	sumaValores += valor;
    	numMuestras++;
        chThdSleepMilliseconds(20);
    }
    valorMedio = (int16_t) (sumaValores/numMuestras);
    chprintf(tty1,"%s min.:%d  average:%d  max.:%d\r\n", msg, valorMin, valorMedio, valorMax);
    return valorMedio;
}

void ajustaRadio(void)
{
	uint8_t opcionRC, opcionOt, *bufferEnt;;
	int16_t valores[8];
	uint32_t variable;
	int32_t ok;
	int i, error, opcion = 0;
	// print actual data
	chprintf(tty1,"Actual data:\n\r");
	printAjustes();
	// adjust RC values
	chprintf(tty1,"Adjust RC values? (1=> yes)");
    opcionRC = chgetch();
    chprintf(tty1,"%c\r\n",opcionRC);
    if (opcionRC == '1')
    {
		valores[0] = ajustaValor("aileron top left", &last_widthTIMAleron);
		valores[1] = ajustaValor("aileron top right", &last_widthTIMAleron);
		valores[2] = ajustaValor("flaps up position (to start crow mix)", &last_widthTIMFlaps);
		valores[3] = ajustaValor("flaps down position", &last_widthTIMFlaps);
    }
	chprintf(tty1,"Adjust other values? (1=> yes)");
    opcionOt = chgetch();
    chprintf(tty1,"%c\r\n",opcionOt);
    if (opcionOt == '1')
    {
		do
		{
			chprintf(tty1,"Crow percentage (%%): ");
			bufferEnt = chgets();
			ok = Str2Int(bufferEnt, &variable);
			if (ok != 0)
			{
				chprintf(tty1,"Illegal input (%d interpreted from %s), ok:%d, repeat!! \r\n",variable,bufferEnt,ok);
				continue;
			}
			valores[4] = (uint16_t) variable;
		} while (ok!=0);
		do
		{
			chprintf(tty1,"\r\nAileron diff. (%%): ");
			bufferEnt = chgets();
			ok = Str2Int(bufferEnt, &variable);
			if (ok != 0)
			{
				chprintf(tty1,"Illegal input (%d interpreted from %s), ok:%d, repeat!! \r\n",variable,bufferEnt,ok);
				continue;
			}
			valores[5] = (uint16_t) variable;
		} while (ok!=0);
		chprintf(tty1,"\r\nInvert left servo (1=> yes):");
		opcion = chgetch();
		chprintf(tty1,"%c\r\n",opcion);
		if (opcion == '1')
			valores[6] = 1;
		else
			valores[6] = 0;
		chprintf(tty1,"Invert right servo (1=> yes):");
		opcion = chgetch();
		chprintf(tty1,"%c\r\n",opcion);
		if (opcion == '1')
			valores[7] = 1;
		else
			valores[7] = 0;
    }
    if (opcionRC!='1' && opcionOt!='1')
    {
    	chprintf(tty1,"No changes made... returning..\n\r");
    	return;
    }
	// print actual data
	chprintf(tty1,"Data collected:\n\r");
	if (opcionRC=='1')
	{
		chprintf(tty1,"  Aileron  %d ..%d\r\n", valores[0], valores[1]);
		chprintf(tty1,"  Flaps   %d ..%d\r\n", valores[2], valores[3]);
	}
	if (opcionOt=='1')
	{
		chprintf(tty1,"  Crow percentage: %d %%\r\n", valores[4]);
		chprintf(tty1,"  Aileron diff.: %d %%\r\n", valores[5]);
		chprintf(tty1,"  Invert left aileron: %d   right servo: %d\r\n\r\n", valores[6], valores[7]);
	}
    chprintf(tty1,"To store this data, press '1': ");
	opcion = chgetch();
	chprintf(tty1,"%c\r\n",opcion);
	if (opcion != '1')
	{
		chprintf(tty1,"As asked, not storing data and returning...\r\n");
	}
	// graba RC data
	if (opcionRC=='1')
	{
		for (i=0;i<=3;i++)
		{
			escribeVariable2bytes(i,valores[i], &error);
			if (error != 0)
			{
				chprintf(tty1,"Error %d when writing %X at position %X, exiting\r\n",error,valores[i],i);
				return;
			}
		}
	}
	// graba otros datos
	if (opcionOt=='1')
	{
		for (i=4;i<8;i++)
		{
			escribeVariable2bytes(i,valores[i], &error);
			if (error != 0)
			{
				chprintf(tty1,"Error %d when writing %X at position %X, exiting\r\n",error,valores[i],i);
				return;
			}
		}
	}
	chprintf(tty1,"Data succesfully stored!\r\n");
	chprintf(tty1,"New data at permanent memory:\n\r");
	leeAjustesDeFlash();
	printAjustes();
}
