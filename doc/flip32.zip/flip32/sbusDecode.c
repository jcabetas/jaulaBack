/*
 * sbusDecode.c
 *
 *  Created on: 27/11/2015
 *      Author: joaquin
 */

/*
 * decode sbus. Returns 1 on error, 0 on success
 */
uint8_t frame2sbus(void)
{
	sbus[0]  = ((buffer[1]    |buffer[2]<<8)                 & 0x07FF);
	sbus[1]  = ((buffer[2]>>3 |buffer[3]<<5)                 & 0x07FF);
	sbus[2]  = ((buffer[3]>>6 |buffer[4]<<2 |buffer[5]<<10)  & 0x07FF);
	sbus[3]  = ((buffer[5]>>1 |buffer[6]<<7)                 & 0x07FF);
	sbus[4]  = ((buffer[6]>>4 |buffer[7]<<4)                 & 0x07FF);
	sbus[5]  = ((buffer[7]>>7 |buffer[8]<<1 |buffer[9]<<9)   & 0x07FF);
	sbus[6]  = ((buffer[9]>>2 |buffer[10]<<6)                & 0x07FF);
	sbus[7]  = ((buffer[10]>>5|buffer[11]<<3)                & 0x07FF);
	sbus[8]  = ((buffer[12]   |buffer[13]<<8)                & 0x07FF);
	sbus[9]  = ((buffer[13]>>3|buffer[14]<<5)                & 0x07FF);
	sbus[10] = ((buffer[14]>>6|buffer[15]<<2|buffer[16]<<10) & 0x07FF);
	sbus[11] = ((buffer[16]>>1|buffer[17]<<7)                & 0x07FF);
	sbus[12] = ((buffer[17]>>4|buffer[18]<<4)                & 0x07FF);
	sbus[13] = ((buffer[18]>>7|buffer[19]<<1|buffer[20]<<9)  & 0x07FF);
	sbus[14] = ((buffer[20]>>2|buffer[21]<<6)                & 0x07FF);
	sbus[15] = ((buffer[21]>>5|buffer[22]<<3)                & 0x07FF);
	return 0;
}


