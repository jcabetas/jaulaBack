/*
    ChibiOS - Copyright (C) 2006..2015 Giovanni Di Sirio

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/


/*
 * Mezclador STM32
 * Placa Flip32
 * 	 InputAleron: TIM2CH1 (RC1, Pin-10, PA0)
 * 	 InputFlaps:  TIM3CH1 (RC5, Pin-16, PA6)
 * 	 Salida Aleron Izq: TIM4CH1 (PWM3, PB6, Pin-42)
 *   Salida Aleron Der: TIM4CH2 (PWM4, PB7, Pin-43)
 *   Salida Flaps Izq:  TIM4CH3 (PWM5, PB8,  Pin-45)
 *   Salida Flaps Der:  TIM4CH4 (PWM6, PB9,  Pin-46)
 *
 * 	 USART: conexión USB 115200 baud
 *
 */

#include "ch.h"
#include "hal.h"
#include "chprintf.h"
#include "tty.h"
#include "vars.h"
#include "string.h"
#include "watchdog.h"



// Prototipos
void arrancaSBUS(void);
void initServo(void);

// variables globales
uint8_t errorVars = 0;
BaseSequentialStream *tty1 = (BaseSequentialStream *)&SD1;
mutex_t mtxSBUS;
uint16_t printSBUS = 0, printPWM = 0;

/*
 * UART driver configuration structure.
 */
//static SerialConfig sdConfig = {
//115200,
//0,
//USART_CR2_STOP1_BITS | USART_CR2_LINEN,
//0
//};


/*
 * Blinker thread (red verde placa base).
 */
static THD_WORKING_AREA(waThreadBL, 128);
static THD_FUNCTION(ThreadBL, arg) {
	(void)arg;
	uint16_t delay;
	chRegSetThreadName("BlinkerLed");
	while (true) {
		if (errorVars) delay = 100; else delay=250;
		palSetPad(GPIOB, GPIOB_GREEN_LED);
		osalThreadSleepMilliseconds(delay);
		palClearPad(GPIOB, GPIOB_GREEN_LED);
		osalThreadSleepMilliseconds(delay);
	}
}

/*
 * Application entry point.
 */
int main(void) {
	char *bufferEnt;
	/*
	 * System initializations.
	 * - HAL initialization, this also initializes the configured device drivers
	 *   and performs the board-specific initializations.
	 * - Kernel initialization, the main() function becomes a thread and the
	 *   RTOS is active.
	 */
	halInit();
	chSysInit();
	/*
	 * Activates the serial driver 1 using the driver default configuration.
	 * PA9(TX) and PA10(RX) are routed to USART1.
	 */
	palClearPad(GPIOA, 9);
    palClearPad(GPIOA,10);
    palSetPadMode(IOPORT1, 9, PAL_MODE_STM32_ALTERNATE_PUSHPULL);
    palSetPadMode(IOPORT1,10, PAL_MODE_INPUT_PULLUP);
	sdStart(&SD1, NULL);
	/*
	 * Preparacion Leds
	 */
	palSetPad(GPIOB, GPIOB_GREEN_LED);
	palSetPad(GPIOB, GPIOB_RED_LED);

	chMtxObjectInit(&mtxSBUS);
	/*
	 * Creates the thread.
	 */
	chThdCreateStatic(waThreadBL, sizeof(waThreadBL), NORMALPRIO+1, ThreadBL, NULL);


	leeAjustesDeFlash();
	initServo();
	arrancaSBUS();
	arrancaWatchDog();
	chprintf(tty1,"Connect:\n\r");
	chprintf(tty1,"- Aileron pwm input to RC-CH1\n\r");
	chprintf(tty1,"- Flaps pwm input to RC-CH5\n\r");
	chprintf(tty1,"- SBUS input to RC-CH4 (optional, for test purposes)\n\r");
	chprintf(tty1,"- Left aileron to PWM3 output\n\r");
	chprintf(tty1,"- Right aileron to PWM4 output\n\r");
	chprintf(tty1,"\n\r");
	do
	{
		if (errorVars==1)
			chprintf(tty1,"Data not initialized... run 'adjust'!\n\r");
		chprintf(tty1,"Write 'adjust' or 'debug': ");
		bufferEnt = (char *) chgets();
		chprintf(tty1,"\n\r");
		if (!strncmp("adjust",bufferEnt,6))
			  ajustaRadio();
		if (!strncmp("debug",bufferEnt,6))
		{
			chprintf(tty1,"Write 'memory', 'pwm' or 'sbus': ");
			bufferEnt = (char *) chgets();
			chprintf(tty1,"\n\r");
			if (!strncmp("memory",bufferEnt,6))
			{
				menuVars();
			}
			if (!strncmp("pwm",bufferEnt,3))
			{
				chprintf(tty1,"PWM values:\n\r");
				osalThreadSleepMilliseconds(100);
				printPWM = 1;
				osalThreadSleepMilliseconds(10000);
				printPWM = 0;
				osalThreadSleepMilliseconds(600);
				chprintf(tty1,"\n\r");
			}
			if (!strncmp("sbus",bufferEnt,4))
			{
				chprintf(tty1,"SBUS test values:\n\r");
				osalThreadSleepMilliseconds(100);
				printSBUS = 1;
				osalThreadSleepMilliseconds(10000);
				printSBUS = 0;
				osalThreadSleepMilliseconds(600);
				chprintf(tty1,"\n\r");
			}
		}
	} while (TRUE);

}
